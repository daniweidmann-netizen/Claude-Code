# 05 – Math Overview

Stand: 25.11.2026 · Konfiguration 1.0.0

> **Prüfstatus aller Zahlen in diesem Dokument:** intern simuliert oder intern berechnet.
> **Unabhängig geprüft: nein. Zertifiziert: nein.** Kein Prüflabor hat Spiel, Zufallsgenerator
> oder Mathematik gesehen. 96,00 % ist ein Entwurfsziel, kein nachgewiesener Wert.
> In diesem Auftrag wurde kein Parameter verändert und keine neue Simulation gefahren.

## 1. Datenlage

| Lauf | Konfiguration (Hash) | Runden | Seed | RTP | 95-%-Intervall | Std.-Abw. | Trefferquote | Datei |
|---|---|---|---|---|---|---|---|---|
| Entwurf | 0.1 (`4b2319b4…`) | 20 Mio. | 20261123 | 1721,95 % | – | 153,03× | 43,21 % | `docs/math/reports/2026-11-23_v0.1-draft_20M.md` |
| Kandidat | 0.2 (`55caa641…`) | 400 Mio. | 20261123 | 95,980 % | 95,860–96,099 | 12,20× | 32,70 % | `…_v0.2-candidate_400M.md` |
| Kandidat | 0.3 (`d2c94def…`) | 1 Mrd. | 20261124 | 95,850 % | 95,719–95,980 | 21,07× | 32,80 % | `…_v0.3-candidate_1G_seedA.md` |
| Abnahme 1 | 0.3.1 (`b6ca9b0d…`) | 2 Mrd. | 20261125 | 96,107 % | 96,014–96,200 | 21,23× | 32,80 % | `…_v0.3.1-candidate_2G_acceptance.md` |
| **Abnahme 2** | **0.3.2** (`3161a5c3…`) | **2 Mrd.** | 20261126 | **95,995 %** | **95,902–96,088** | 21,14× | 32,80 % | `…_v0.3.2-candidate_2G_acceptance.md` |
| **Abnahme auf 1.0.0** | **1.0.0** (`943082d6…`) | 2 Mrd. | 20261126 | **95,995 %** | 95,902–96,088 | 21,14× | 32,80 % | `2026-11-25_v1.0.0_2G_acceptance.md` |
| Zusatzwerte | 1.0.0 (`943082d6…`) | 100 Mio. | 20261128 | 95,941 % | – | – | – | `2026-11-25_v1.0.0_extra-stats_100M.md` |
| Feature-Kauf | 0.3.3 (`71630094…`) | 100 Mio. Käufe | 20261127 | 95,815 % bei Preis 58,6× | 95,752–95,879 | 189,51× | – | `…_v0.3.3-candidate_featurebuy_100M.md` |
| **Feature-Kauf auf 1.0.0** | **1.0.0** (`943082d6…`) | 100 Mio. Käufe | 20261129 | **96,831 % bei Preis 58×** | 96,767–96,895 | 189,58× | – | `2026-11-25_v1.0.0_featurebuy_100M.md` |

Einordnung der Läufe:

- 0.1 war ein unausgeglichener Erstentwurf (RTP 1722 %); er belegt nur, dass der Simulator lief.
- 0.3 → 0.3.1 → 0.3.2 sind Abstimmungsschritte. 0.3.1 lag ausserhalb der eigenen Toleranz
  (±0,10 Prozentpunkte um 96,00 %); daraufhin wurde ein Schatzpreis von 15× auf 14× gesenkt.
  Das ist dokumentiert und kein Widerspruch, sondern der Verlauf der Abstimmung.
- **Konfiguration 1.0.0 selbst ist seit dem 25.11.2026 gemessen.** Der Abnahmelauf wurde mit der
  ausgelieferten Konfiguration (SHA-256 `943082d640a065931a87d21e3bb84a953ae27ba653531d4303b22857d75698e3`,
  im Bericht gekürzt `943082d640a06593`) und demselben Seed 20261126 wiederholt. Ergebnis:
  **alle Zähler bitgenau identisch** mit dem Lauf auf 0.3.2 (Gewinnsumme 191 990 090 170 Hundertstel-Einsätze
  über 2 000 000 000 Runden, gleiche Verteilungen, gleiche zehn grössten Gewinne). Damit ist belegt,
  dass 0.3.2 und 1.0.0 für normale Runden dieselben Spielwerte haben. Der Vergleich der beiden
  Konfigurationen im Versionsverlauf zeigt als einzige Unterschiede die Versionsnummer und den
  Block «Feature-Kauf». Bericht: `docs/math/reports/2026-11-25_v1.0.0_2G_acceptance.md`.
  Hinweis: Weil derselbe Seed verwendet wurde, ist das eine Gleichheitsprüfung und **keine
  zusätzliche statistische Stichprobe**; die Unsicherheit des RTP bleibt beim angegebenen Intervall.
- **Feature-Kauf:** Der erste Lauf (0.3.3) rechnete mit Preis 58,6× und ergab 95,82 %; daraus wurde
  für den ausgelieferten Preis 58× ein RTP von 96,81 % **abgeleitet** (56,148 ÷ 58). Am 25.11.2026
  wurde der Kauf **direkt auf Konfiguration 1.0.0 bei 58×** simuliert (100 Mio. Käufe, neuer Seed
  20261129): mittlerer Gewinn 56,162× (±0,037), **RTP 96,831 %** (95-%-Intervall 96,767–96,895 %).
  Beide Werte liegen innerhalb der gegenseitigen Intervalle; der abgeleitete Wert ist bestätigt.
  Beide Läufe zusammen (200 Mio. Käufe): 56,155× → 96,82 %. Im Spiel angezeigt wird weiterhin
  96,81 % (Intervall 96,74–96,87 %) aus dem ersten Lauf.

## 2. Kennzahlen (normale Runden, Abnahme 2)

Methode: Monte-Carlo-Simulation mit der Spiel-Engine selbst (`tools/sim/`), 4 unabhängige
Zufallsströme, 2 000 000 000 Runden. «Z.» = Zeile im Bericht `…_v0.3.2-candidate_2G_acceptance.md`
(der Bericht auf 1.0.0 hat dieselben Zeilen und Werte);
«JSON» = gleichnamige `.json`-Datei.

| Kennzahl | Wert | Quelle | Art | Unabh. geprüft | Zertifiziert |
|---|---|---|---|---|---|
| Ziel-RTP | 96,00 % | `docs/04_MATH_MODELING_PLAN.md` | Entwurfsziel | nein | nein |
| RTP | 95,9950 % | Z. 21 | simuliert | nein | nein |
| 95-%-Konfidenzintervall | 95,9024–96,0877 % | Z. 22 | simuliert | nein | nein |
| Standardfehler | 0,0473 % (analytisch) / 0,0538 % (Blockmittel) | Z. 24 | simuliert | nein | nein |
| Standardabweichung je Runde | 21,141× Einsatz | Z. 23 | simuliert | nein | nein |
| Volatilität | «hoch» – Einordnung des Entwicklers anhand Std.-Abw. und Verteilung; keine anerkannte Skala angewendet | `docs/12_CLUSTER_RULE_CONFIRMATION.md` | Einschätzung | nein | nein |
| Hit Frequency (Basis-Spin mit Cluster) – siehe Erklärung unter der Tabelle | 32,795 % | Z. 34 | simuliert | nein | nein |
| Win Frequency (Runden mit Gewinn) | 33,011 % | Z. 35 | simuliert | nein | nein |
| Mittlerer Gewinn je Runde | 0,95995× Einsatz | = RTP | simuliert | nein | nein |
| Mittlerer Gewinn je **Gewinnrunde** | 2,908× Einsatz | abgeleitet: JSON `sumWin` ÷ `roundsWithWin` | abgeleitet | nein | nein |
| Kaskaden je Basis-Spin (Mittel) | 0,650 | abgeleitet aus Z. 73–98 | abgeleitet | nein | nein |
| Kaskaden je Basis-Spin mit Gewinn (Mittel) | 1,982 | abgeleitet | abgeleitet | nein | nein |
| Längste Kaskadenfolge | 23 (Grenze 50 nie erreicht) | Z. 40–41 | simuliert | nein | nein |
| Free Spins, alle Wege | 1 in 222,1 Runden | Z. 36 | simuliert | nein | nein |
| Free Spins über Compass | 1 in 238,1 | Z. 37 | simuliert | nein | nein |
| Free Spins über den Temple Bonus | 1 in 3267 | abgeleitet: JSON `fsFromBonus` | abgeleitet | nein | nein |
| 3+ Compass beim ersten Fall | 0,2785 % | Z. 122 | exakt berechnet (Binomial) | nein | nein |
| Mittlere Free Spins je Feature | 8,21 | Z. 107 | simuliert | nein | nein |
| Retrigger-Frequenz | 1,360 % der Features haben mindestens einen Retrigger (1 in 73,5); 1 Retrigger je 596 Free Spins; 1 in 16 305 Runden | Zusatzlauf 100 Mio. Runden auf 1.0.0: `docs/math/reports/2026-11-25_v1.0.0_extra-stats_100M.md` | simuliert | nein | nein |
| Mittlerer Feature-Gewinn inkl. Finale | 67,90× (Std.-Abw. 212,44×) | Z. 105–106 | simuliert | nein | nein |
| Mittlerer End-Sonnenbonus im Feature | 14,72 (höchster Wert 400) | Z. 108 | simuliert | nein | nein |
| Mittlerer Multiplikator je Gewinnkaskade | Basisrunde 1,42 (gewinngewichtet 1,46) · Free Spins 9,47 (9,94) · gesamt 1,91 (2,06) | Zusatzlauf wie oben | simuliert | nein | nein |
| Temple Bonus in der Basisrunde | 1 in 326,1 | Z. 38 | simuliert | nein | nein |
| Mittlerer Gewinn Temple Bonus (Basis) | 50,826× simuliert · 50,971× exakt | Z. 116 | beides | nein | nein |
| Temple Finale 1/2/3 Siegel | 63,034 / 176,550 / 454,174× simuliert · 63,360 / 174,954 / 476,347× exakt | Z. 117–119 | beides | nein | nein |
| Free Spins aus dem Basis-Bonus | 9,980 % simuliert · 9,991 % exakt | Z. 121 | beides | nein | nein |
| Höchstgewinn | 10 000× Einsatz | Konfig. Z. 7 | Regel | nein | nein |
| Höchstgewinn erreicht | 659-mal, 1 in 3 034 901 | Z. 39 | simuliert | nein | nein |
| Feature-Kauf: mittlerer Gewinn | 56,162× (±0,037) auf 1.0.0 · 56,148× (±0,037) im ersten Lauf | `2026-11-25_v1.0.0_featurebuy_100M.md`; `…_v0.3.3-…` Z. 14 | simuliert | nein | nein |
| Feature-Kauf: RTP bei 58× | 96,831 % (96,767–96,895) simuliert auf 1.0.0 · 96,81 % abgeleitet aus dem ersten Lauf | wie oben | simuliert / abgeleitet | nein | nein |
| Feature-Kauf: Standardabweichung | 189,58× Einsatz je Kauf | wie oben | simuliert | nein | nein |
| Feature-Kauf: Höchstgewinn erreicht | 1 in 18 252 Käufen (erster Lauf: 1 in 17 940) | wie oben | simuliert | nein | nein |

**Warum zwei Trefferangaben?** 32,80 % ist der Anteil der Runden, deren **Basis-Spin** mindestens
einen Cluster hat (Hit Frequency). 33,01 % ist der Anteil der Runden, die **irgendetwas**
auszahlen (Win Frequency). Die Differenz von 0,216 Prozentpunkten sind Runden, deren Basis-Spin
keinen Cluster hat, die aber über drei Compass-Symbole Free Spins auslösen und dort gewinnen.
Jede Runde mit Cluster im Basis-Spin zahlt etwas; umgekehrt gilt das nicht. Für Provider-Unterlagen
ist die übliche «Hit Frequency» die erste Zahl; beide stammen aus demselben Lauf
(JSON `baseHits` = 655 907 798, `roundsWithWin` = 660 211 562 von 2 000 000 000).

## 3. RTP-Aufteilung (Z. 25–28)

| Quelle | Anteil am RTP |
|---|---|
| Cluster der Basisrunde | 49,836 % |
| Temple Bonus der Basisrunde | 15,588 % |
| **Basisrunde gesamt** | **65,424 %** |
| Cluster der Free Spins | 25,738 % |
| Temple Finale | 4,834 % |
| **Free-Spin-Feature gesamt** | **30,571 %** |

## 4. Gewinnverteilung je Runde (Z. 45–58)

| Gewinn (× Einsatz) | Anteil | | Gewinn | Anteil |
|---|---|---|---|---|
| 0 | 66,989 % | | 20 bis <50 | 0,236 % |
| über 0 bis <1 | 17,765 % | | 50 bis <100 | 0,095 % |
| 1 bis <2 | 7,910 % | | 100 bis <500 | 0,082 % |
| 2 bis <5 | 5,372 % | | 500 bis <1000 | 0,0071 % |
| 5 bis <10 | 1,199 % | | 1000 bis <5000 | 0,0053 % |
| 10 bis <20 | 0,339 % | | ab 5000 | 0,00021 % |

## 5. Symbolgewichte und -wahrscheinlichkeiten (Konfig. Z. 8–29)

| Symbol | Gewicht Basis | Anteil | Gewicht Free Spins | Anteil |
|---|---|---|---|---|
| Sapphire Gem | 2000 | 20,42 % | 2000 | 20,72 % |
| Golden Scarab | 1950 | 19,91 % | 1950 | 20,21 % |
| Golden Chalice | 1900 | 19,40 % | 1900 | 19,69 % |
| Ruby Crown | 1850 | 18,89 % | 1850 | 19,17 % |
| Jade Mask | 1800 | 18,38 % | 1800 | 18,65 % |
| Wild | 0 | 0 % | 0 | 0 % |
| Compass | 92 | 0,94 % | 60 | 0,62 % |
| Temple Key | 200 | 2,04 % | 91 | 0,94 % |
| Summe | 9792 | | 9651 | |

Anteile = Gewicht ÷ Summe (hier berechnet). Zahlende Cluster je 1000 Runden nach Symbol und
Grösse: Bericht Z. 124–132. Sun-Relic-Werte: Basis 2 (500) · 3 (280) · 5 (150) · 10 (55) · 25 (15);
Free Spins 5 (480) · 10 (290) · 25 (150) · 50 (60) · 100 (20) – Konfig. Z. 101–144.
Paytable und Bonus-Preistabellen: `04_Feature_Overview.md`.

## 6. Absicherung der Zahlen (intern)

| Prüfung | Ergebnis | Quelle |
|---|---|---|
| Exakte Teilrechnungen (Bonus-Erwartungswerte, Compass beim ersten Fall) gegen Simulation | stimmen innerhalb der Streuung; Abweichung bei 3 Siegeln durch Kappung erklärt | Bericht Z. 112–122 |
| Unabhängige Zweitimplementierung in Python, Runde für Runde verglichen | identisch; zuletzt 80 000 Runden am 25.11.2026 (Seed 20261125) | `tools/reference/`, `docs/12_CLUSTER_RULE_CONFIRMATION.md` |
| Eigenschaftsbasierte Tests (jedes Ereignisprotokoll regelkonform) | bestanden | `tests/property/round.property.test.ts` |
| Clusterregel in 4000 echten Runden nachgeprüft | bestanden | `tests/integration/cluster-rule.test.ts` |
| Eingefrorene Konfiguration mit Prüfsumme | bestanden | `tests/unit/frozen-config.test.ts` |

## 7. Was fehlt

| Fehlend | Bedeutung |
|---|---|
| Unabhängige Prüfung und Zertifizierung | Voraussetzung für jeden regulierten Markt |
| Weitere RTP-Varianten (üblich sind mehrere je Titel) | nur eine vorhanden; Werkzeuge existieren |
| Gewinn je Station | vom Simulator nicht erfasst |
| Anerkannte Volatilitätskennzahl des Zielanbieters | jeder Anbieter rechnet nach eigener Skala |
| Statistische Testbatterie für den Zufallsgenerator (z. B. TestU01, PractRand) | nicht ausgeführt |
| Anteil des durch die Kappung abgeschnittenen Gewinns | nicht ausgewiesen |
| Vollständige Enumeration auf einem Miniaturraster als Gegenprobe | geplant, nicht durchgeführt |
